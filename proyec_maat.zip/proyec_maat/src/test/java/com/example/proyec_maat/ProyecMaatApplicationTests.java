package com.example.proyec_maat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyecMaatApplicationTests {

	@Test
	void contextLoads() {
	}

}
