package com.example.proyec_maat.Repositorio;

import com.example.proyec_maat.Entidad.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface RepositorioCliente extends JpaRepository<Cliente, String> {

    ArrayList<Cliente> findBynombres_cli(String nombres_cli);
    ArrayList<Cliente> findByapellidos_cli(String apellidos_cli);
    ArrayList<Cliente> findBytelefono_cli(String telefono_cli);
    ArrayList<Cliente> findByemail_cli(String email_cli);




    //id_Cliente-nombres_cli-apellidos_cli-telefono_cli-email_cli
}
