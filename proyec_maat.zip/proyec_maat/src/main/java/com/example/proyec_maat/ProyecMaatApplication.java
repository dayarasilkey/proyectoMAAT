package com.example.proyec_maat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyecMaatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyecMaatApplication.class, args);
	}

}
