package com.example.proyec_maat.Entidad;

import jakarta.persistence.Column;
import jakarta.persistence.Id;

public class Cliente {

    @Id
    @Column(length = 20)
    private String id_Cliente;
    @Column(nullable = false, length= 30)
    private String nombres_cli;
    @Column(nullable = false, length= 30)
    private String apellidos_cli;
    @Column(nullable = false,length = 15)
    private String telefono_cli;
    @Column(nullable = false, length= 50, unique = true)
    private String email_cli;

    public Cliente() {
    }

    public Cliente(String id_Cliente, String nombres_cli, String apellidos_cli, String telefono_cli, String email_cli) {
        this.id_Cliente = id_Cliente;
        this.nombres_cli = nombres_cli;
        this.apellidos_cli = apellidos_cli;
        this.telefono_cli = telefono_cli;
        this.email_cli = email_cli;
    }


    public String getId_Cliente() {
        return id_Cliente;
    }

    public void setId_Cliente(String id_Cliente) {
        this.id_Cliente = id_Cliente;
    }

    public String getNombres_cli() {
        return nombres_cli;
    }

    public void setNombres_cli(String nombres_cli) {
        this.nombres_cli = nombres_cli;
    }

    public String getApellidos_cli() {
        return apellidos_cli;
    }

    public void setApellidos_cli(String apellidos_cli) {
        this.apellidos_cli = apellidos_cli;
    }

    public String getTelefono_cli() {
        return telefono_cli;
    }

    public void setTelefono_cli(String telefono_cli) {
        this.telefono_cli = telefono_cli;
    }

    public String getEmail_cli() {
        return email_cli;
    }

    public void setEmail_cli(String email_cli) {
        this.email_cli = email_cli;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "id_Cliente='" + id_Cliente + '\'' +
                ", nombres_cli='" + nombres_cli + '\'' +
                ", apellidos_cli='" + apellidos_cli + '\'' +
                ", telefono_cli='" + telefono_cli + '\'' +
                ", email_cli='" + email_cli + '\'' +
                '}';
    }


}
