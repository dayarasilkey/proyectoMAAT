package com.example.proyec_maat.Servicio;

import com.example.proyec_maat.Entidad.Cliente;
import com.example.proyec_maat.Repositorio.RepositorioCliente;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServicioCliente {

    private RepositorioCliente repositorio;

    public ServicioCliente(RepositorioCliente repositorio) {
        this.repositorio = repositorio;
    }

    public ArrayList<Cliente> ListarClientes() {
        return (ArrayList<Cliente>) repositorio.findAll();
    }

    public Cliente buscarCliente(String id_Cliente) {
        if (repositorio.findById(id_Cliente).isPresent())
            return repositorio.findById(id_Cliente).get();
        else return null;
    }

    public ArrayList<Cliente> buscarNombres(String nombres_cli) {
        return repositorio.findBynombres_cli(nombres_cli);
    }

    public ArrayList<Cliente> buscarApellido(String apellidos_cli) {
        return repositorio.findByapellidos_cli(apellidos_cli);
    }

    public ArrayList<Cliente> buscarTelefono(String telefono_cli) {
        return repositorio.findBytelefono_cli(telefono_cli);
    }

    public ArrayList<Cliente> buscarEmail(String email_cli) {
        return repositorio.findByemail_cli(email_cli);
    }


    public String agregarCliente(Cliente cliente) {

        if (repositorio.findById(cliente.getId_Cliente()).isPresent())
            return "El Cliente ya se encuentra registrado";
        else
            repositorio.save(cliente);
        return "El Cliente se registro exitosamente.";

    }


    public String actualizarCliente(Cliente cliente) {

        if (repositorio.findById(cliente.getId_Cliente()).isPresent()){
            repositorio.save(cliente);
            return "El Cliente se actualizo exitosamente.";
        }
        else{
            return "El Cliente no se encuentra registrado";

        }
    }


    public String eliminarCliente(String id_Cliente) {
        if (repositorio.findById(id_Cliente).isPresent()) {
            repositorio.deleteById(id_Cliente);
            return "El Cliente eliminado";
        } else {
            return "El estudiante no se encuentra registrado";
        }
    }




}
