package com.example.proyec_maat.Controlador;

import com.example.proyec_maat.Entidad.Cliente;
import com.example.proyec_maat.Servicio.ServicioCliente;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
public class ControladorCliente {

    private ServicioCliente servicio;

    public ControladorCliente(ServicioCliente servicio) {
        this.servicio = servicio;
    }

    @GetMapping("/ListarClientes")
    public ArrayList<Cliente> Listarcli(){
        return servicio.ListarClientes();
    }

    @GetMapping ("/buscarNombres/{doc}")
    ArrayList<Cliente> buscarNombres(@PathVariable("doc")String id_Cliente){
        return  servicio.buscarNombres(id_Cliente);
    }

    @GetMapping ("/buscarNombre/{nombre}")
    public ArrayList<Cliente> buscarNombre(@PathVariable("nombre")String b){
        return servicio.buscarNombres(b);
    }

    @GetMapping ("/buscarApellido/{apellido}")
    public ArrayList<Cliente> buscarApellido(@PathVariable("apellido")String a){
        return servicio.buscarApellido(a);
    }

    @GetMapping ("/buscarTelefono/{telefono}")
    public ArrayList<Cliente> buscarTelefono(@PathVariable("telefono")String t){
        return servicio.buscarTelefono(t);
    }

    @GetMapping ("/buscarEmail/{email}")
    public ArrayList<Cliente> buscarEmail(@PathVariable("email")String t){
        return servicio.buscarEmail(t);
    }

    @PostMapping("/agregarcliente")
    public  String agregarCliente(@RequestBody Cliente cliente){
        return servicio.agregarCliente(cliente);
    }

    @PutMapping("/actualizarcCliente")
    public  String actualizarCliente(@RequestBody Cliente cliente){
        return servicio.actualizarCliente(cliente);
    }

    @DeleteMapping("/eliminarCliente/{doc}")
    public String eliminarCliente(@PathVariable("doc") String documento){
        return servicio.eliminarCliente(documento);
    }
}
